# Dodge the Creeps 2D assets

Used by the "Your first 2D game" tutorial:

https://docs.godotengine.org/en/latest/getting_started/first_2d_game/index.html
